﻿namespace MoveEstimator
{
    partial class MoveEstimator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            calculateButton = new Button();
            numberOfHoursLabel = new Label();
            numberOfMilesLabel = new Label();
            estimatedCostLabel = new Label();
            estimatedCostOutput = new Label();
            numOfHoursInput = new TextBox();
            numOfMilesInput = new TextBox();
            SuspendLayout();
            // 
            // calculateButton
            // 
            calculateButton.Location = new Point(120, 250);
            calculateButton.Name = "calculateButton";
            calculateButton.Size = new Size(94, 29);
            calculateButton.TabIndex = 0;
            calculateButton.Text = "Calculate";
            calculateButton.UseVisualStyleBackColor = true;
            calculateButton.Click += CalculateButton_Click;
            // 
            // numberOfHoursLabel
            // 
            numberOfHoursLabel.AutoSize = true;
            numberOfHoursLabel.Location = new Point(120, 80);
            numberOfHoursLabel.Name = "numberOfHoursLabel";
            numberOfHoursLabel.Size = new Size(156, 20);
            numberOfHoursLabel.TabIndex = 1;
            numberOfHoursLabel.Text = "Enter number of hours";
            // 
            // numberOfMilesLabel
            // 
            numberOfMilesLabel.AutoSize = true;
            numberOfMilesLabel.Location = new Point(120, 140);
            numberOfMilesLabel.Name = "numberOfMilesLabel";
            numberOfMilesLabel.Size = new Size(155, 20);
            numberOfMilesLabel.TabIndex = 2;
            numberOfMilesLabel.Text = "Enter number of miles";
            // 
            // estimatedCostLabel
            // 
            estimatedCostLabel.AutoSize = true;
            estimatedCostLabel.Location = new Point(120, 200);
            estimatedCostLabel.Name = "estimatedCostLabel";
            estimatedCostLabel.Size = new Size(108, 20);
            estimatedCostLabel.TabIndex = 3;
            estimatedCostLabel.Text = "Estimated Cost";
            // 
            // estimatedCostOutput
            // 
            estimatedCostOutput.BorderStyle = BorderStyle.Fixed3D;
            estimatedCostOutput.Location = new Point(390, 200);
            estimatedCostOutput.Name = "estimatedCostOutput";
            estimatedCostOutput.Size = new Size(125, 27);
            estimatedCostOutput.TabIndex = 4;
            // 
            // numOfHoursInput
            // 
            numOfHoursInput.Location = new Point(390, 80);
            numOfHoursInput.Name = "numOfHoursInput";
            numOfHoursInput.Size = new Size(125, 27);
            numOfHoursInput.TabIndex = 5;
            // 
            // numOfMilesInput
            // 
            numOfMilesInput.Location = new Point(390, 140);
            numOfMilesInput.Name = "numOfMilesInput";
            numOfMilesInput.Size = new Size(125, 27);
            numOfMilesInput.TabIndex = 6;
            // 
            // MoveEstimator
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(632, 353);
            Controls.Add(numOfMilesInput);
            Controls.Add(numOfHoursInput);
            Controls.Add(estimatedCostOutput);
            Controls.Add(estimatedCostLabel);
            Controls.Add(numberOfMilesLabel);
            Controls.Add(numberOfHoursLabel);
            Controls.Add(calculateButton);
            Name = "MoveEstimator";
            Text = "Move Estimator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button calculateButton;
        private Label numberOfHoursLabel;
        private Label numberOfMilesLabel;
        private Label estimatedCostLabel;
        private Label estimatedCostOutput;
        private TextBox numOfHoursInput;
        private TextBox numOfMilesInput;
    }
}
