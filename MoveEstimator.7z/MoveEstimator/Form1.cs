namespace MoveEstimator
{
    public partial class MoveEstimator : Form
    {
        public MoveEstimator()
        {
            InitializeComponent();
        }
        private void CalculateButton_Click(object sender, EventArgs e)
        {
            string numOfHours, numOfMiles;
            int hours, miles, estCost;
            numOfHours = numOfHoursInput.Text;
            hours = Convert.ToInt32(numOfHours);
            numOfMiles = numOfMilesInput.Text;
            miles = Convert.ToInt32(numOfMiles);
            estCost = (hours * 150) + (miles * 2) + 200;
            estimatedCostOutput.Text = estCost.ToString("C");
        }
    }
}
